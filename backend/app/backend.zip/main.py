import os
import shutil
import uuid
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from PIL import Image

client = OpenAI()

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="AI-Translate MVP")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"status": "ok", "msg": "AI-Translate backend running"}


# ---------------------------------------------------------
# 1. UPLOAD
# ---------------------------------------------------------
@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    file_id = str(uuid.uuid4())
    dest = UPLOAD_DIR / f"{file_id}_{file.filename}"

    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)

    return {"status": "ok", "filename": dest.name, "path": str(dest)}


# ---------------------------------------------------------
# 2. PROCESS (audio, image → text → translation → paraphrase)
# ---------------------------------------------------------
@app.post("/process")
async def process(
    filename: str = Form(...),
    translate_to: str = Form("ru"),
    style: str = Form("normal")
):
    path = UPLOAD_DIR / filename
    if not path.exists():
        return JSONResponse(status_code=404, content={"error": "file not found"})

    ext = path.suffix.lower()

    # ---------- AUDIO ----------
    if ext in [".mp3", ".wav", ".m4a", ".mp4", ".webm", ".aac", ".ogg"]:
        with open(path, "rb") as audio:
            transcript = client.audio.transcriptions.create(
                file=audio,
                model="gpt-4o-transcribe"
            ).text

        source = "audio"
        text = transcript

    # ---------- IMAGE ----------
    elif ext in [".jpg", ".jpeg", ".png", ".bmp", ".tiff"]:
        img = Image.open(path)

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Extract all readable text from the image."},
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "Extract text"},
                        {
                            "type": "input_image",
                            "image_url": f"data:image/png;base64,{path.read_bytes().hex()}"
                        }
                    ]
                }
            ]
        )

        text = response.choices[0].message["content"]
        source = "image"

    else:
        return JSONResponse(status_code=400, content={"error": "unsupported file type"})

    # ---------- TRANSLATE ----------
    translation = client.chat.completions.create(
        model="gpt-4o-mini-translate",
        messages=[
            {"role": "system", "content": f"Translate text into {translate_to}"},
            {"role": "user", "content": text}
        ]
    ).choices[0].message["content"]

    # ---------- PARAPHRASE ----------
    paraphrased = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": f"Paraphrase in {translate_to} with style: {style}"},
            {"role": "user", "content": translation}
        ]
    ).choices[0].message["content"]

    # ---------- SAVE FILES ----------
    out_txt = OUTPUT_DIR / f"{path.stem}_translation.txt"
    out_txt.write_text(translation, encoding="utf-8")

    out_para = OUTPUT_DIR / f"{path.stem}_paraphrase_{style}.txt"
    out_para.write_text(paraphrased, encoding="utf-8")

    resp = {
        "source": source,
        "original_text": text,
        "translation": translation,
        "paraphrase": paraphrased,
        "files": {
            "translation_txt": str(out_txt),
            "paraphrase_txt": str(out_para)
        }
    }

    return resp


# ---------------------------------------------------------
# 3. PARAPHRASE ONLY
# ---------------------------------------------------------
@app.post("/paraphrase")
async def paraphrase_endpoint(text: str = Form(...), style: str = Form("hype")):
    out = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": f"Paraphrase in style {style}"},
            {"role": "user", "content": text}
        ]
    ).choices[0].message["content"]

    return {"paraphrase": out}


# ---------------------------------------------------------
# 4. TTS (OpenAI text → speech)
# ---------------------------------------------------------
@app.post("/tts")
async def tts_endpoint(text: str = Form(...), lang: str = Form("ru"), voice: str = Form("alloy")):
    speech = client.audio.speech.create(
        model="gpt-4o-mini-tts",
        voice=voice,
        input=text
    )

    file_out = OUTPUT_DIR / f"tts_{uuid.uuid4()}.mp3"
    speech.stream_to_file(str(file_out))

    return FileResponse(str(file_out), media_type="audio/mpeg", filename=file_out.name)
